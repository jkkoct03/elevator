package com.devon.elevetor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElevatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
