package com.devon.elevetor;

public enum ElevatorStatus {
	ELEVATOR_OCCUPIED, ELEVATOR_EMPTY;
}
