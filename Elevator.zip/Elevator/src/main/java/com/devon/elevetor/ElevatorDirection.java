package com.devon.elevetor;

public enum ElevatorDirection {

	ELEVATOR_UP, ELEVATOR_DOWN, ELEVATOR_HOLD
}
